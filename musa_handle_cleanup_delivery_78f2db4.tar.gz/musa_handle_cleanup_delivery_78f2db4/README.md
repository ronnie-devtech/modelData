# MUSA 句柄与 timing 文件一次性诊断包

本包对应修复提交：

```text
78f2db4123cc19822527be660300008503cd3b51
```

本包已在 sj12 的 `ronnie-musa438-mudnn520-validation-3215` 容器中实测，使用
3.3.8 driver 和 `original_JDdata`，完整执行了以下诊断命令：

```text
exit_code=0
completed_queries=9600
actual_qps=159.820
OrtApi::Run p99=19.177 ms
MUSA completion p99=12.708 ms
timing 文件全部生成
MUBLAS_STATUS_INTERNAL_ERROR=0
失败 musaFree=0
```

sj12 容器未安装 `strace`，因此本次验证目录记录了
`strace_unavailable.txt`；`LD_DEBUG=libs`、动态库校验和 timing 文件状态均已
成功采集。

包内的 `libonnxruntime.so.1.18.0` 和 `libmusa_free_trace.so` 来自同一次
构建，不能拆开使用。`libmusa_free_trace.so` 只用于诊断，会增加开销，
诊断运行结果不能用于性能验收。

## 1. 设置路径

在客户容器中解压本包，进入解压目录，设置三个路径：

```bash
cd musa_handle_cleanup_delivery_78f2db4

export ONNXRUNTIME_ROOT=/export/chenxuan/onnxruntime
export MODEL_DATA_ROOT=/export/chenxuan/original_JDdata
export RESULT_ROOT=/export/chenxuan/ort_test/result
```

`MODEL_DATA_ROOT` 必须包含：

```text
optimized_model.onnx
device.txt
req_799_npz/
```

`RESULT_ROOT` 必须可写。脚本默认使用 `/usr/local/musa`、GPU `0` 和 CPU
核 `0-13`；如果客户的空闲 14 核不同，可以设置：

```bash
export MUSA_HOME=/usr/local/musa
export MUSA_DIAG_CPU_LIST=0-13
```

脚本会自动把 `$ONNXRUNTIME_ROOT/thirdparty/METIS_LIB/lib` 和
`$ONNXRUNTIME_ROOT/thirdparty/gfortran` 加入动态库搜索路径，并在其后加入
`/usr/local/musa/lib`。如果客户没有这些目录，需先按 JD-MUSA 构建文档准备
对应依赖。

## 2. 执行诊断

```bash
chmod +x *.sh
./run_parallel_diagnostic.sh
```

该脚本使用与 `docs/JD-MUSA_BUILD_AND_BENCHMARK.md` 相同的 parallel 参数：

```text
mode=uniform
qps=160
workers=16
execution-mode=parallel
parallel-inter-op=12
CPU arena=关闭
warmup=20 秒
采集=60 秒
```

脚本还会固定启用：

```text
ORT_MUSA_ENABLE_TF32=1
ORT_MUSA_ALLOCATOR_CACHE_LIMIT_MB=4096
ORT_SESSION_MEMCPY_USE_MEMORY_POOL_ON=0
ORT_MUSA_HANDLE_DIAGNOSTICS=1
```

默认只记录失败的 `musaFree`，避免在 MUSA runtime 线程退出阶段对每一次成功
释放做回溯而干扰退出流程。如果需要记录所有成功释放，可显式设置：

```bash
export MUSA_DIAG_TRACE_ALL=1
```

全量 trace 会明显增加日志量和退出开销，首次客户诊断不建议开启。

默认同时开启 `strace` 和 `LD_DEBUG=libs`，用于定位 timing 文件路径、权限、
flush/rename 以及实际加载的动态库。若客户环境没有 `strace`，脚本会记录
`strace_unavailable.txt`，不会阻止诊断继续执行。

## 3. 回传文件

命令结束时会打印：

```text
[MUSA_DIAG] diagnostic_dir=...
```

诊断目录位于实际结果目录旁边；如果 `RESULT_ROOT/parallel` 已有内容，脚本
会自动创建新的 `parallel_diagnostic_时间戳` 目录，避免旧结果影响本次运行。

将该目录完整回传。至少需要：

```text
run_info.txt
environment.txt
libraries.txt
timing_before.txt
timing_after.txt
timing_diagnostic.txt
stdout.log
stderr.log
exit_code.txt
strace.*
```

如果存在，也回传：

```text
musa_timing.csv
musa_timing.csv.boundary.csv
musa_timing.csv.d2h_sync.csv
```

不存在的 timing 文件不要手工创建空文件。

若 `exit_code.txt` 为 `134`，再执行：

```bash
ulimit -c unlimited
```

重新运行后，如产生 core，再回传：

```bash
gdb -batch -ex 'thread apply all bt full' -ex quit \
  python core > core_backtrace.txt 2>&1
```

## 4. 如何判断

```text
mublasDestroy=1 + MUBLAS_STATUS_INTERNAL_ERROR
```

表示仍然走到了 muBLAS handle destructor 的失败释放路径。结合
`libraries.txt` 检查实际加载的 ORT、muBLAS 和 MUSA runtime。

```text
mublasDestroy=0
```

表示失败来自其他 MUSA runtime/TLS 清理路径。

```text
[MUSA_TIMING_DIAGNOSTIC] status=missing
```

表示 `musa_timing.csv.boundary.csv` 或 `musa_timing.csv.d2h_sync.csv` 没有
生成。结合 `timing_before.txt`、`timing_after.txt`、`stderr.log` 和
`strace.*` 可以判断是输出目录、权限、文件名/版本不匹配，还是进程在
flush/rename 前退出。

## 5. 包内文件 SHA256

```text
libonnxruntime.so.1.18.0
49f0c32eafbdea001c63c55abb879e758ad8579384cd11830dd975116a83cf4c

libmusa_free_trace.so
f2d40a926257d2a7c3d2e34f16f9eee1dd62abaae78b33306a03135c3d68d537

pressure_native_capi.py
7296d14f18af5bacfb967716faf9efd74658ebd6ccb478a36fe737498fb6ed1d

run_inference_native_capi.py
b33f3de43affc7484063ef6a56fd39ab0d7374ca7f0875ecda9bdceabf8c3923
```

客户运行前可执行：

```bash
sha256sum libonnxruntime.so.1.18.0 libmusa_free_trace.so \
  pressure_native_capi.py run_inference_native_capi.py
```
