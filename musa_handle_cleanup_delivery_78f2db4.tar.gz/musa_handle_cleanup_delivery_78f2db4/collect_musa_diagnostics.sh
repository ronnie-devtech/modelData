#!/usr/bin/env bash
set -u

die() { echo "[MUSA_DIAG] ERROR: $*" >&2; exit 2; }

ort_lib=""
trace_lib=""
result_dir=""
clean_timing=0
enable_strace="${MUSA_DIAG_STRACE:-0}"
enable_ld_debug="${MUSA_DIAG_LD_DEBUG:-0}"
trace_all="${MUSA_DIAG_TRACE_ALL:-0}"
command_args=()

while (($# > 0)); do
  case "$1" in
    --ort-lib) (($# >= 2)) || die "--ort-lib requires a path"; ort_lib=$2; shift 2 ;;
    --trace-lib) (($# >= 2)) || die "--trace-lib requires a path"; trace_lib=$2; shift 2 ;;
    --result-dir) (($# >= 2)) || die "--result-dir requires a path"; result_dir=$2; shift 2 ;;
    --clean-timing) clean_timing=1; shift ;;
    --) shift; command_args=("$@"); break ;;
    *) die "unknown option '$1'" ;;
  esac
done

[[ -f "$ort_lib" ]] || die "ORT library does not exist: $ort_lib"
[[ -f "$trace_lib" ]] || die "trace library does not exist: $trace_lib"
[[ -n "$result_dir" ]] || die "missing --result-dir"
((${#command_args[@]} > 0)) || die "missing command after --"
mkdir -p "$result_dir" || die "cannot create result directory: $result_dir"

run_id="$(date +%Y%m%d_%H%M%S)_$$"
diag_dir="${result_dir}.musa_diagnostic_$run_id"
mkdir -p "$diag_dir" || die "cannot create diagnostic directory"
if ((clean_timing)); then
  rm -f "$result_dir"/musa_timing.csv* "$result_dir"/musa_completion_timing.csv* \
    2>"$diag_dir/clean_timing.err" || true
fi

{
  echo "run_id=$run_id"; echo "date=$(date -Is)"; echo "hostname=$(hostname 2>/dev/null || true)"
  echo "kernel=$(uname -a 2>/dev/null || true)"; echo "cwd=$(pwd)"; echo "uid=$(id -u 2>/dev/null || true)"
  printf 'command='; printf '%q ' "${command_args[@]}"; echo
  echo "ort_lib=$ort_lib"; echo "trace_lib=$trace_lib"; echo "result_dir=$result_dir"
  echo "MUSA_DIAG_STRACE=$enable_strace"; echo "MUSA_DIAG_LD_DEBUG=$enable_ld_debug"
  echo "MUSA_DIAG_TRACE_ALL=$trace_all"
  env | grep -E '^(ORT_|MUSA_|LD_|CUDA_VISIBLE_DEVICES|OMP_|MKL_|GOMP_)' | sort || true
} >"$diag_dir/run_info.txt"

{
  echo '--- driver ---'; cat /proc/driver/musa/version 2>&1 || true
  echo '--- CPU/NUMA ---'; lscpu 2>&1 || true; numactl --hardware 2>&1 || true
} >"$diag_dir/environment.txt"

{
  echo '--- SHA256 ---'; sha256sum "$ort_lib" "$trace_lib" 2>&1 || true
  echo '--- ldd ORT ---'; ldd "$ort_lib" 2>&1 || true
  echo '--- resolved MUSA libraries ---'
  for pattern in "${MUSA_HOME:-/usr/local/musa}/lib/libmusart.so*" \
                 "${MUSA_HOME:-/usr/local/musa}/lib/libmublas.so*" \
                 "${MUSA_HOME:-/usr/local/musa}/lib/libmudnn.so*"; do
    for file in $pattern; do
      [[ -e "$file" || -L "$file" ]] || continue
      printf '%s -> ' "$file"; readlink -f "$file" 2>&1 || true; sha256sum "$file" 2>&1 || true
    done
  done
} >"$diag_dir/libraries.txt"

{
  find "$result_dir" -maxdepth 1 -type f -printf '%f %s bytes %TY-%Tm-%Td %TH:%TM:%TS\n' 2>&1 | sort || true
  stat -c '%A %U:%G %a %n' "$result_dir" 2>&1 || true; df -h "$result_dir" 2>&1 || true
} >"$diag_dir/timing_before.txt"

export ORT_MUSA_HANDLE_DIAGNOSTICS=1
if [[ "$trace_all" != 0 ]]; then
  export ORT_MUSA_FREE_TRACE_ALL=1
else
  unset ORT_MUSA_FREE_TRACE_ALL
fi
export LD_LIBRARY_PATH="$(dirname "$ort_lib"):${MUSA_HOME:-/usr/local/musa}/lib:${LD_LIBRARY_PATH:-}"
export LD_PRELOAD="$trace_lib${LD_PRELOAD:+:$LD_PRELOAD}"

set +e
if [[ "$enable_strace" != 0 ]] && command -v strace >/dev/null 2>&1; then
  if [[ "$enable_ld_debug" != 0 ]]; then
    LD_DEBUG=libs strace -ff -tt -T -s 256 \
      -e trace=openat,creat,rename,renameat,renameat2,write,fsync,fdatasync,close,stat,statx \
      -o "$diag_dir/strace" "${command_args[@]}" >"$diag_dir/stdout.log" 2>"$diag_dir/stderr.log"
  else
    strace -ff -tt -T -s 256 \
      -e trace=openat,creat,rename,renameat,renameat2,write,fsync,fdatasync,close,stat,statx \
      -o "$diag_dir/strace" "${command_args[@]}" >"$diag_dir/stdout.log" 2>"$diag_dir/stderr.log"
  fi
  rc=$?
else
  [[ "$enable_strace" == 0 ]] || echo '[MUSA_DIAG] strace is not installed' >"$diag_dir/strace_unavailable.txt"
  if [[ "$enable_ld_debug" != 0 ]]; then
    LD_DEBUG=libs "${command_args[@]}" >"$diag_dir/stdout.log" 2>"$diag_dir/stderr.log"
  else
    "${command_args[@]}" >"$diag_dir/stdout.log" 2>"$diag_dir/stderr.log"
  fi
  rc=$?
fi
set -e
printf '%s\n' "$rc" >"$diag_dir/exit_code.txt"

{
  find "$result_dir" -maxdepth 1 -type f -printf '%f %s bytes %TY-%Tm-%Td %TH:%TM:%TS\n' 2>&1 | sort || true
  for file in "$result_dir/musa_timing.csv" "$result_dir/musa_timing.csv.boundary.csv" "$result_dir/musa_timing.csv.d2h_sync.csv"; do
    [[ -f "$file" ]] && stat -c 'PRESENT %A %U:%G %s bytes %n' "$file" 2>&1 || echo "MISSING $file"
  done
  find "$result_dir" -maxdepth 2 -type f \( -iname '*timing*' -o -iname '*boundary*' -o -iname '*d2h*' \) -printf '%p %s bytes\n' 2>&1 | sort || true
} >"$diag_dir/timing_after.txt"

if [[ ! -f "$result_dir/musa_timing.csv.boundary.csv" || ! -f "$result_dir/musa_timing.csv.d2h_sync.csv" ]]; then
  cat >"$diag_dir/timing_diagnostic.txt" <<'EOF'
[MUSA_TIMING_DIAGNOSTIC] status=missing
Check timing_before.txt, timing_after.txt, stderr.log and strace.* for path,
permission, producer/consumer version, flush or rename failures.
EOF
else
  echo '[MUSA_TIMING_DIAGNOSTIC] status=present' >"$diag_dir/timing_diagnostic.txt"
fi
cat "$diag_dir/timing_diagnostic.txt"
echo "[MUSA_DIAG] exit_code=$rc"
echo "[MUSA_DIAG] diagnostic_dir=$diag_dir"
exit "$rc"
