#!/usr/bin/env python3
"""MUSA ORT C API open-loop benchmark aligned with the CUDA reference.

延迟统计使用 ORTSession.run() 返回的 run_time（仅 OrtApi::Run 调用本身，
不含输入准备 / 输出转换）。

两种负载模式：
* uniform: 每 1/QPS 秒投放一条请求；
* batch:   每 workers/QPS 秒同时投放 workers 条请求。

用法（在 19923 上）:
  cd /export/chenxuan/ort_test && source env.sh
  python3 pressure_benchmark_musa.py --mode uniform --qps 160 --workers 8 --duration 60
"""

from __future__ import annotations

import argparse
import csv
import json
import os
import queue
from collections import defaultdict
import threading
import time
import random
from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional, Sequence

import numpy as np

from run_inference_native_capi import (
    CApiSession as ORTSession,
    ONNX_TO_NP_DTYPE,
    ORT_API_VERSION,
    PreparedRequest,
    PreparedRunContext,
    get_model_input_dtypes,
    ORT_PARALLEL,
)

# The native runner intentionally has no model/request defaults: using a
# different recommendation graph would invalidate placement and precision
# conclusions for this migration.
INTRA_OP_THREADS = 4
INTER_OP_THREADS = 1
EXECUTION_MODE = "ORT_SEQUENTIAL"


@dataclass(frozen=True)
class Query:
    query_id: int
    wave_id: int
    sample_index: int
    scheduled_time: float
    enqueue_time: float
    release_event: Optional[threading.Event] = None


@dataclass(frozen=True)
class LatencyRecord:
    query_id: int
    wave_id: int
    sample_index: int
    scheduled_time: float
    enqueue_time: float
    run_start_time: float
    run_time_ms: float       # ORTSession.run() 返回的 run_time（仅 OrtApi::Run）
    run_end_time: float
    host_tid: int
    ort_run_start_ns: int
    ort_run_end_ns: int


@dataclass
class WorkerResult:
    records: list[LatencyRecord] = field(default_factory=list)
    warmup_runs: int = 0


def default_output_dir() -> Path:
    timestamp = time.strftime("%Y%m%d_%H%M%S")
    return Path("pressure_results") / timestamp


def loaded_mudnn_libraries() -> list[str]:
    """Return the muDNN objects actually mapped into this process."""
    try:
        maps = Path("/proc/self/maps").read_text(errors="replace")
    except OSError:
        return []

    libraries = set()
    for line in maps.splitlines():
        fields = line.split()
        if not fields:
            continue
        path = fields[-1]
        if path.startswith("/") and "libmudnn" in Path(path).name:
            libraries.add(str(Path(path).resolve()))
    return sorted(libraries)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="开环 ORT 压测，延迟仅统计 OrtApi::Run 耗时。",
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    parser.add_argument("--model", type=Path, required=True)
    parser.add_argument("--request-dir", type=Path, required=True)
    parser.add_argument(
        "--device-placement-file",
        type=Path,
        required=True,
    )
    parser.add_argument("--ort-library", type=Path, default=None)
    parser.add_argument("--device-id", type=int, default=0)
    parser.add_argument("--mode", choices=("uniform", "batch", "poisson"), default="uniform")
    parser.add_argument("--qps", type=float, default=160.0)
    parser.add_argument("--workers", type=int, default=8)
    parser.add_argument(
        "--execution-mode",
        choices=("sequential", "parallel"),
        default="sequential",
        help=(
            "sequential uses intra=4/inter=1; parallel uses "
            "ORT_PARALLEL, intra=1 and graph partition mode 6"
        ),
    )
    parser.add_argument("--parallel-inter-op", type=int, default=8,
                        help="Global inter-op pool size in parallel mode (default: 8).")
    parser.add_argument("--disable-cpu-mem-arena", action="store_true",
                        help="Disable only the CPU arena for allocator contention A/B tests.")
    parser.add_argument("--warmup-seconds", type=float, default=20.0)
    parser.add_argument("--duration", type=float, default=60.0)
    parser.add_argument(
        "--prepared-c-api",
        action="store_true",
        help=(
            "Pre-create input OrtValues and reuse per-worker output OrtValues; "
            "this removes C API wrapper allocation/release from the load path."
        ),
    )
    parser.add_argument("--limit", type=int, default=None, help=argparse.SUPPRESS)
    parser.add_argument("--progress", type=int, default=100, help=argparse.SUPPRESS)
    parser.add_argument("--output-dir", type=Path, default=None)
    return parser.parse_args()


def validate_args(args: argparse.Namespace) -> None:
    if args.parallel_inter_op < 1:
        raise SystemExit("--parallel-inter-op must be positive")
    if args.qps <= 0:
        raise SystemExit("--qps must be positive")
    if args.workers <= 0:
        raise SystemExit("--workers must be positive")
    if args.warmup_seconds < 0:
        raise SystemExit("--warmup-seconds must be non-negative")
    if args.duration <= 0:
        raise SystemExit("--duration must be positive")
    if args.limit is not None and args.limit <= 0:
        raise SystemExit("--limit must be positive")
    if args.progress < 0:
        raise SystemExit("--progress must be non-negative")


def request_sort_key(path: Path) -> tuple[int, object, str]:
    prefix = path.name.split("_", 1)[0]
    if prefix.isdigit():
        return 0, int(prefix), path.name
    return 1, path.name, path.name


def load_requests(
    session: ORTSession, request_dir: Path, limit: Optional[int]
) -> list[dict[str, np.ndarray]]:
    """加载请求 npz，按模型输入 dtype 转换。"""
    paths = sorted(request_dir.glob("*.npz"), key=request_sort_key)
    if limit is not None:
        paths = paths[:limit]
    if not paths:
        raise FileNotFoundError(f"No .npz files under {request_dir}")

    input_types = get_model_input_dtypes(session.model_path)
    requests: list[dict[str, np.ndarray]] = []
    for path in paths:
        with np.load(path, allow_pickle=False) as archive:
            feed_dict = {}
            for name in session.input_names:
                if name not in archive:
                    raise FileNotFoundError(
                        f"{path} is missing input '{name}'"
                    )
                arr = archive[name]
                expected = ONNX_TO_NP_DTYPE.get(input_types.get(name, 0))
                if expected and arr.dtype != expected:
                    arr = arr.astype(expected)
                feed_dict[name] = arr
            requests.append(feed_dict)
    return requests


def run_one(session: ORTSession, request: dict[str, np.ndarray]) -> float:
    """跑一条请求，返回 run_time（秒）。释放 output OrtValues。"""
    output_vals, run_time = session.run(request)
    session.release_outputs(output_vals)
    return run_time


def run_one_timed(
    session: ORTSession, request: dict[str, np.ndarray]
) -> tuple[float, int, int]:
    """Run one request and return the exact OrtApi::Run interval."""
    output_vals, run_time, start_ns, end_ns = session.run(
        request, include_timestamps=True
    )
    session.release_outputs(output_vals)
    return run_time, start_ns, end_ns


def prepared_output_key(request: dict[str, np.ndarray]) -> int:
    """All 38 outputs of this recommendation model have leading dimension R."""
    name = "item_sid_row_widths"
    if name not in request or request[name].ndim == 0:
        raise ValueError(f"Prepared mode requires a ranked '{name}' input")
    return int(request[name].shape[0])


def run_one_prepared(
    session: ORTSession,
    request: PreparedRequest,
    context: PreparedRunContext,
) -> float:
    return session.run_prepared(request, context)


def run_one_prepared_timed(
    session: ORTSession,
    request: PreparedRequest,
    context: PreparedRunContext,
) -> tuple[float, int, int]:
    return session.run_prepared(request, context, include_timestamps=True)


def record_error(
    errors: list[BaseException], error_lock: threading.Lock, error: BaseException
) -> None:
    with error_lock:
        errors.append(error)


def worker_loop(
    worker_id: int,
    worker_count: int,
    session: ORTSession,
    requests: Sequence[dict[str, np.ndarray]],
    prepared_requests: Optional[Sequence[PreparedRequest]],
    prepared_context: Optional[PreparedRunContext],
    work_queue: "queue.Queue[Query]",
    producer_done: threading.Event,
    stop_event: threading.Event,
    warmup_barrier: threading.Barrier,
    warmup_start: threading.Event,
    warmup_start_time: list[float],
    warmup_seconds: float,
    ready_barrier: threading.Barrier,
    start_event: threading.Event,
    result: WorkerResult,
    errors: list[BaseException],
    error_lock: threading.Lock,
    progress_every: int,
) -> None:
    try:
        host_tid = threading.get_native_id()
        warmup_barrier.wait()
        warmup_start.wait()
        deadline = warmup_start_time[0] + warmup_seconds
        warmup_index = 0
        while time.perf_counter() < deadline:
            sample_index = (worker_id + warmup_index * worker_count) % len(requests)
            if prepared_requests is None:
                run_one(session, requests[sample_index])
            else:
                assert prepared_context is not None
                run_one_prepared(
                    session,
                    prepared_requests[sample_index],
                    prepared_context,
                )
            result.warmup_runs += 1
            warmup_index += 1

        ready_barrier.wait()
        start_event.wait()
        processed = 0
        while not stop_event.is_set():
            try:
                query = work_queue.get(timeout=0.05)
            except queue.Empty:
                if producer_done.is_set():
                    return
                continue
            try:
                if query.release_event is not None:
                    query.release_event.wait()
                run_start_time = time.perf_counter()
                if prepared_requests is None:
                    run_time, ort_run_start_ns, ort_run_end_ns = run_one_timed(
                        session, requests[query.sample_index]
                    )
                else:
                    assert prepared_context is not None
                    run_time, ort_run_start_ns, ort_run_end_ns = (
                        run_one_prepared_timed(
                            session,
                            prepared_requests[query.sample_index],
                            prepared_context,
                        )
                    )
                run_end_time = time.perf_counter()
                result.records.append(
                    LatencyRecord(
                        query.query_id,
                        query.wave_id,
                        query.sample_index,
                        query.scheduled_time,
                        query.enqueue_time,
                        run_start_time,
                        run_time * 1000.0,
                        run_end_time,
                        host_tid,
                        ort_run_start_ns,
                        ort_run_end_ns,
                    )
                )
                processed += 1
                if progress_every and processed % progress_every == 0:
                    print(
                        f"[worker {worker_id}] {processed} done, "
                        f"last run={run_time * 1000.0:.3f}ms",
                        flush=True,
                    )
            finally:
                work_queue.task_done()
    except BaseException as exc:
        stop_event.set()
        for barrier in (warmup_barrier, ready_barrier):
            try:
                barrier.abort()
            except threading.BrokenBarrierError:
                pass
        record_error(errors, error_lock, exc)


def producer_loop(
    mode: str,
    qps: float,
    workers: int,
    request_count: int,
    sample_count: int,
    start_event: threading.Event,
    start_time: list[float],
    work_queue: "queue.Queue[Query]",
    producer_done: threading.Event,
    stop_event: threading.Event,
    max_backlog: list[int],
    backlog_lock: threading.Lock,
    errors: list[BaseException],
    error_lock: threading.Lock,
) -> None:
    try:
        start_event.wait()
        dispatch_size = 1 if (mode == "uniform" or mode == "poisson") else workers
        last_time = start_time[0]
        for first_query_id in range(0, request_count, dispatch_size):
            if stop_event.is_set():
                return
            wave_id = first_query_id // dispatch_size
            if mode == "poisson":
                scheduled_time = last_time + random.expovariate(qps)
            else:
                scheduled_time = last_time + dispatch_size / qps

            last_time = scheduled_time
            delay = scheduled_time - time.perf_counter()
            if delay > 0:
                time.sleep(delay)

            release_event = threading.Event() if mode == "batch" else None
            last_query_id = min(first_query_id + dispatch_size, request_count)
            for query_id in range(first_query_id, last_query_id):
                enqueue_time = time.perf_counter()
                work_queue.put(
                    Query(
                        query_id,
                        wave_id,
                        query_id % sample_count,
                        scheduled_time,
                        enqueue_time,
                        release_event,
                    )
                )
            with backlog_lock:
                max_backlog[0] = max(max_backlog[0], work_queue.qsize())
            if release_event is not None:
                release_event.set()
    except BaseException as exc:
        stop_event.set()
        record_error(errors, error_lock, exc)
    finally:
        producer_done.set()


def latency_summary(records: Sequence[LatencyRecord]) -> tuple[float, float, float, float]:
    """返回 (avg, p50, p99, max) ms，基于 OrtApi::Run 耗时。"""
    if not records:
        return float("nan"), float("nan"), float("nan"), float("nan")
    values = np.asarray(
        [record.run_time_ms for record in records], dtype=np.float64
    )
    return (
        float(np.mean(values)),
        float(np.percentile(values, 50)),
        float(np.percentile(values, 99)),
        float(np.max(values)),
    )


def metric_summary(values: Sequence[float]) -> tuple[float, float, float, float]:
    if not values:
        return float("nan"), float("nan"), float("nan"), float("nan")
    array = np.asarray(values, dtype=np.float64)
    return (
        float(np.mean(array)),
        float(np.percentile(array, 50)),
        float(np.percentile(array, 99)),
        float(np.max(array)),
    )


def configure_musa_completion_timing(output_dir: Path) -> Path:
    """Capture the existing D2H boundary without adding synchronization."""
    output_dir.mkdir(parents=True, exist_ok=True)
    timing_csv = output_dir / "musa_timing.csv"
    for path in (
        timing_csv,
        Path(str(timing_csv) + ".boundary.csv"),
        Path(str(timing_csv) + ".d2h_sync.csv"),
        output_dir / "musa_completion.csv",
    ):
        path.unlink(missing_ok=True)
    os.environ["ORT_MUSA_PROFILE_TIMING"] = "1"
    os.environ["ORT_MUSA_PROFILE_TIMING_BACKEND"] = "boundary"
    os.environ["ORT_MUSA_PROFILE_TIMING_CAPTURE"] = "0"
    os.environ["ORT_MUSA_PROFILE_TIMING_SYNC"] = "0"
    os.environ["ORT_MUSA_PROFILE_TIMING_OUTPUT"] = str(timing_csv)
    return timing_csv


def parse_musa_completion_timing(
    output_dir: Path, timing_csv: Path, expected_count: int
) -> dict[str, object]:
    """Split each H2D-submit to full BatchMemcpyToHost completion interval."""
    boundary_csv = Path(str(timing_csv) + ".boundary.csv")
    d2h_sync_csv = Path(str(timing_csv) + ".d2h_sync.csv")
    if not boundary_csv.is_file() or not d2h_sync_csv.is_file():
        raise RuntimeError(
            "MUSA boundary timing files were not produced: "
            f"{boundary_csv}, {d2h_sync_csv}"
        )

    boundaries: list[dict[str, int]] = []
    with boundary_csv.open(newline="", encoding="utf-8") as csv_file:
        for row in csv.DictReader(csv_file):
            boundaries.append(
                {
                    "run": int(row["run"]),
                    "start_ns": int(row["start_ns"]),
                    "end_ns": int(row["end_ns"]),
                    "host_tid": int(row["host_tid"]),
                    "key": int(row["boundary_key"]),
                }
            )

    syncs_by_stream: dict[int, list[dict[str, int]]] = defaultdict(list)
    native_sync_count = 0
    with d2h_sync_csv.open(newline="", encoding="utf-8") as csv_file:
        for row in csv.DictReader(csv_file):
            if row["kind"] != "native_batch_stream":
                continue
            native_sync_count += 1
            key = int(row["stream_key"])
            syncs_by_stream[key].append(
                {
                    "start_ns": int(row["start_ns"]),
                    "end_ns": int(row["end_ns"]),
                    "host_tid": int(row["host_tid"]),
                }
            )
    for syncs in syncs_by_stream.values():
        syncs.sort(key=lambda sample: sample["start_ns"])

    next_sync = defaultdict(int)
    rows: list[tuple[int, int, int, float, float, float, float]] = []
    stale_syncs = 0
    host_tid_mismatches = 0
    for boundary in sorted(boundaries, key=lambda sample: sample["start_ns"]):
        stream_syncs = syncs_by_stream.get(boundary["key"], [])
        index = next_sync[boundary["key"]]
        while (
            index < len(stream_syncs)
            and stream_syncs[index]["end_ns"] < boundary["start_ns"]
        ):
            stale_syncs += 1
            index += 1
        if (
            index >= len(stream_syncs)
            or stream_syncs[index]["start_ns"] < boundary["start_ns"]
            or stream_syncs[index]["end_ns"] > boundary["end_ns"]
        ):
            next_sync[boundary["key"]] = index
            continue
        sync = stream_syncs[index]
        next_sync[boundary["key"]] = index + 1
        if sync["host_tid"] != boundary["host_tid"]:
            host_tid_mismatches += 1

        pre_sync_ms = (sync["start_ns"] - boundary["start_ns"]) / 1.0e6
        sync_ms = (sync["end_ns"] - sync["start_ns"]) / 1.0e6
        host_memcpy_ms = (boundary["end_ns"] - sync["end_ns"]) / 1.0e6
        completion_ms = (boundary["end_ns"] - boundary["start_ns"]) / 1.0e6
        rows.append(
            (
                boundary["run"],
                boundary["host_tid"],
                boundary["key"],
                pre_sync_ms,
                sync_ms,
                host_memcpy_ms,
                completion_ms,
            )
        )

    completion_csv = output_dir / "musa_completion.csv"
    with completion_csv.open("w", newline="", encoding="utf-8") as csv_file:
        writer = csv.writer(csv_file)
        writer.writerow(
            (
                "boundary_run",
                "host_tid",
                "stream_key",
                "h2d_submit_to_d2h_sync_ms",
                "d2h_sync_wait_ms",
                "d2h_post_sync_cleanup_ms",
                "musa_completion_ms",
            )
        )
        for row in rows:
            writer.writerow((*row[:3], *(f"{value:.6f}" for value in row[3:])))

    pre_sync_values = [row[3] for row in rows]
    sync_values = [row[4] for row in rows]
    post_sync_cleanup_values = [row[5] for row in rows]
    completion_values = [row[6] for row in rows]
    pre_sync_avg, pre_sync_p50, pre_sync_p99, pre_sync_max = metric_summary(
        pre_sync_values
    )
    sync_avg, sync_p50, sync_p99, sync_max = metric_summary(sync_values)
    (
        post_sync_cleanup_avg,
        post_sync_cleanup_p50,
        post_sync_cleanup_p99,
        post_sync_cleanup_max,
    ) = metric_summary(post_sync_cleanup_values)
    completion_avg, completion_p50, completion_p99, completion_max = (
        metric_summary(completion_values)
    )
    pair_count = len(rows)
    return {
        "musa_timing_backend": "boundary",
        "musa_completion_definition": (
            "BatchMemcpyFromHost H2D submission start through the final "
            "BatchMemcpyToHost synchronous cleanup completion, including "
            "CPU-side host memcpy and pinned staging-buffer reclamation"
        ),
        "musa_completion_end_marker": "batch_memcpy_to_host_cleanup_end",
        "musa_completion_extra_stream_synchronize": False,
        "musa_boundary_count": len(boundaries),
        "musa_native_d2h_sync_count": native_sync_count,
        "musa_completion_count": pair_count,
        "musa_completion_expected_count": expected_count,
        "musa_completion_count_match": pair_count == expected_count,
        "musa_completion_unpaired_boundaries": len(boundaries) - pair_count,
        "musa_completion_stale_syncs": stale_syncs,
        "musa_completion_host_tid_mismatches": host_tid_mismatches,
        "h2d_submit_to_d2h_sync_avg_ms": pre_sync_avg,
        "h2d_submit_to_d2h_sync_p50_ms": pre_sync_p50,
        "h2d_submit_to_d2h_sync_p99_ms": pre_sync_p99,
        "h2d_submit_to_d2h_sync_max_ms": pre_sync_max,
        "d2h_sync_wait_avg_ms": sync_avg,
        "d2h_sync_wait_p50_ms": sync_p50,
        "d2h_sync_wait_p99_ms": sync_p99,
        "d2h_sync_wait_max_ms": sync_max,
        "d2h_post_sync_cleanup_avg_ms": post_sync_cleanup_avg,
        "d2h_post_sync_cleanup_p50_ms": post_sync_cleanup_p50,
        "d2h_post_sync_cleanup_p99_ms": post_sync_cleanup_p99,
        "d2h_post_sync_cleanup_max_ms": post_sync_cleanup_max,
        # Keep the old keys for readers of existing result schemas. Their
        # value now covers the complete post-sync kernel cleanup interval.
        "d2h_host_memcpy_avg_ms": post_sync_cleanup_avg,
        "d2h_host_memcpy_p50_ms": post_sync_cleanup_p50,
        "d2h_host_memcpy_p99_ms": post_sync_cleanup_p99,
        "d2h_host_memcpy_max_ms": post_sync_cleanup_max,
        "musa_completion_avg_ms": completion_avg,
        "musa_completion_p50_ms": completion_p50,
        "musa_completion_p99_ms": completion_p99,
        "musa_completion_max_ms": completion_max,
        "musa_timing_csv": str(timing_csv),
        "musa_boundary_csv": str(boundary_csv),
        "musa_d2h_sync_csv": str(d2h_sync_csv),
        "musa_completion_csv": str(completion_csv),
    }


def write_results(
    output_dir: Path,
    args: argparse.Namespace,
    request_count: int,
    sample_count: int,
    records: Sequence[LatencyRecord],
    start_time: float,
    end_time: float,
    max_backlog: int,
    errors: Sequence[BaseException],
    musa_timing: dict[str, object],
    session_memcpy_use_memory_pool_on: int,
) -> dict[str, object]:
    output_dir.mkdir(parents=True, exist_ok=True)
    records = sorted(records, key=lambda record: record.query_id)
    latency_csv = output_dir / "latency.csv"
    with latency_csv.open("w", newline="", encoding="utf-8") as csv_file:
        writer = csv.writer(csv_file)
        writer.writerow(("query_id", "wave_id", "sample_index", "run_time_ms"))
        for record in records:
            writer.writerow(
                (
                    record.query_id,
                    record.wave_id,
                    record.sample_index,
                    f"{record.run_time_ms:.6f}",
                )
            )

    diagnostics_csv = output_dir / "diagnostics.csv"
    scheduled_values: list[float] = []
    queue_values: list[float] = []
    wall_values: list[float] = []
    with diagnostics_csv.open("w", newline="", encoding="utf-8") as csv_file:
        writer = csv.writer(csv_file)
        writer.writerow(
            (
                "query_id",
                "wave_id",
                "sample_index",
                "scheduled_latency_ms",
                "schedule_delay_ms",
                "queue_wait_ms",
                "wall_run_ms",
                "ort_run_ms",
                "host_tid",
                "ort_run_start_ns",
                "ort_run_end_ns",
            )
        )
        for record in records:
            scheduled_latency = (
                record.run_end_time - record.scheduled_time
            ) * 1000.0
            schedule_delay = (
                record.enqueue_time - record.scheduled_time
            ) * 1000.0
            queue_wait = (
                record.run_start_time - record.enqueue_time
            ) * 1000.0
            wall_run = (
                record.run_end_time - record.run_start_time
            ) * 1000.0
            scheduled_values.append(scheduled_latency)
            queue_values.append(queue_wait)
            wall_values.append(wall_run)
            writer.writerow(
                (
                    record.query_id,
                    record.wave_id,
                    record.sample_index,
                    f"{scheduled_latency:.6f}",
                    f"{schedule_delay:.6f}",
                    f"{queue_wait:.6f}",
                    f"{wall_run:.6f}",
                    f"{record.run_time_ms:.6f}",
                    record.host_tid,
                    record.ort_run_start_ns,
                    record.ort_run_end_ns,
                )
            )

    scheduled_avg, scheduled_p50, scheduled_p99, scheduled_max = metric_summary(
        scheduled_values
    )
    queue_avg, queue_p50, queue_p99, queue_max = metric_summary(queue_values)
    wall_avg, wall_p50, wall_p99, wall_max = metric_summary(wall_values)

    elapsed = max(0.0, end_time - start_time)
    actual_qps = len(records) / elapsed if elapsed > 0 else 0.0
    drain_time_ms = max(0.0, elapsed - args.duration) * 1000.0
    latency_avg_ms, latency_p50_ms, latency_p99_ms, latency_max_ms = latency_summary(records)
    scheduled_qps = request_count / args.duration
    overload = (
        len(records) != request_count
        or drain_time_ms > max(args.duration * 50.0, 1000.0 / args.qps)
        or max_backlog > args.workers
    )
    valid = not errors and len(records) == request_count
    summary = {
        "model": str(args.model),
        "request_dir": str(args.request_dir),
        "device_placement_file": str(args.device_placement_file),
        "device_id": args.device_id,
        "ort_version": f"1.{ORT_API_VERSION}.0",
        "providers": ["MUSAExecutionProvider", "CPUExecutionProvider"],
        "session_profile": (
            "in_tree_musa_parallel_mode6_global_pool"
            if args.execution_mode == "parallel"
            else "in_tree_musa_sequential_global_pool"
        ),
        "global_intra_op_threads": args.intra_op_threads,
        "global_inter_op_threads": args.inter_op_threads,
        "execution_mode": args.execution_mode,
        "graph_partition_mode": args.graph_partition_mode,
        "disable_per_session_threads": True,
        "disable_cpu_mem_arena": args.disable_cpu_mem_arena,
        "session_memcpy_use_memory_pool_on": session_memcpy_use_memory_pool_on,
        "graph_optimization_level": "ORT_DISABLE_ALL",
        "io_binding": False,
        "prepared_c_api": args.prepared_c_api,
        "musa_plugin": False,
        "musa_physical_streams_per_run": 1,
        "loaded_mudnn_libraries": loaded_mudnn_libraries(),
        "runtime_environment": {
            key: value
            for key, value in sorted(os.environ.items())
            if key == "LD_LIBRARY_PATH"
            or key.startswith("MUSA_")
            or key.startswith("MUDNN_")
            or key.startswith("ORT_MUSA_")
            or key.startswith("ORT_SESSION_")
        },
        "ort_library": str(args.ort_library) if args.ort_library is not None else os.environ.get("ORT_MUSA_ORT_LIB"),
        "cpu_affinity": sorted(os.sched_getaffinity(0)),
        "cpu_process_seconds": args.cpu_process_seconds,
        "cpu_process_avg_percent": 100.0 * args.cpu_process_seconds / (end_time - start_time) / len(os.sched_getaffinity(0)),
        "mode": args.mode,
        "workers": args.workers,
        "target_qps": args.qps,
        "scheduled_qps": scheduled_qps,
        "warmup_seconds": args.warmup_seconds,
        "duration_seconds": args.duration,
        "loaded_samples": sample_count,
        "scheduled_queries": request_count,
        "completed_queries": len(records),
        "valid": valid,
        "invalid_reason": (
            "; ".join(repr(error) for error in errors)
            if errors
            else ("request_count_mismatch" if len(records) != request_count else None)
        ),
        "actual_qps": actual_qps,
        "elapsed_seconds": elapsed,
        "drain_time_ms": drain_time_ms,
        "max_backlog": max_backlog,
        "latency_avg_ms": latency_avg_ms,
        "latency_p50_ms": latency_p50_ms,
        "latency_p99_ms": latency_p99_ms,
        "latency_max_ms": latency_max_ms,
        "scheduled_latency_avg_ms": scheduled_avg,
        "scheduled_latency_p50_ms": scheduled_p50,
        "scheduled_latency_p99_ms": scheduled_p99,
        "scheduled_latency_max_ms": scheduled_max,
        "queue_wait_avg_ms": queue_avg,
        "queue_wait_p50_ms": queue_p50,
        "queue_wait_p99_ms": queue_p99,
        "queue_wait_max_ms": queue_max,
        "wall_run_avg_ms": wall_avg,
        "wall_run_p50_ms": wall_p50,
        "wall_run_p99_ms": wall_p99,
        "wall_run_max_ms": wall_max,
        "overload": overload,
        "runtime_errors": [repr(error) for error in errors],
        "latency_csv": str(latency_csv),
        "diagnostics_csv": str(diagnostics_csv),
        **musa_timing,
    }
    summary_path = output_dir / "summary.json"
    summary_path.write_text(json.dumps(summary, indent=2, sort_keys=True) + "\n")
    print(f"target_qps={args.qps:.3f}")
    print(f"scheduled_qps={scheduled_qps:.3f}")
    print(f"actual_qps={actual_qps:.3f}")
    print(f"scheduled_queries={request_count}")
    print(f"completed_queries={len(records)}")
    print(f"latency_avg_ms={latency_avg_ms:.3f}")
    print(f"latency_p50_ms={latency_p50_ms:.3f}")
    print(f"latency_p99_ms={latency_p99_ms:.3f}")
    print(f"latency_max_ms={latency_max_ms:.3f}")
    print(f"scheduled_latency_p99_ms={scheduled_p99:.3f}")
    print(f"queue_wait_p99_ms={queue_p99:.3f}")
    print(f"wall_run_p99_ms={wall_p99:.3f}")
    print(f"musa_completion_count={musa_timing['musa_completion_count']}")
    print(
        "musa_completion_count_match="
        f"{str(musa_timing['musa_completion_count_match']).lower()}"
    )
    print(
        f"musa_completion_avg_ms="
        f"{musa_timing['musa_completion_avg_ms']:.3f}"
    )
    print(
        f"musa_completion_p99_ms="
        f"{musa_timing['musa_completion_p99_ms']:.3f}"
    )
    print(f"overload={'true' if overload else 'false'}")
    print(f"valid={'true' if valid else 'false'}")
    print(f"summary={summary_path}")
    print(f"latency_csv={latency_csv}")
    print(f"diagnostics_csv={diagnostics_csv}")
    return summary


def run(args: argparse.Namespace) -> int:
    args.model = args.model.expanduser().resolve()
    args.request_dir = args.request_dir.expanduser().resolve()
    args.device_placement_file = args.device_placement_file.expanduser().resolve()
    args.output_dir = (
        args.output_dir.expanduser().resolve()
        if args.output_dir is not None
        else default_output_dir().resolve()
    )
    if not args.model.is_file():
        raise FileNotFoundError(f"Model does not exist: {args.model}")
    if not args.request_dir.is_dir():
        raise FileNotFoundError(f"Request directory does not exist: {args.request_dir}")
    if not args.device_placement_file.is_file():
        raise FileNotFoundError(
            "Device placement file does not exist: "
            f"{args.device_placement_file}"
        )
    if args.output_dir.exists() and any(args.output_dir.iterdir()):
        raise FileExistsError(f"Output directory is not empty: {args.output_dir}")

    timing_csv = configure_musa_completion_timing(args.output_dir)
    if args.execution_mode == "parallel":
        args.intra_op_threads = 1
        args.inter_op_threads = args.parallel_inter_op
        args.graph_partition_mode = 6
    else:
        args.intra_op_threads = INTRA_OP_THREADS
        args.inter_op_threads = INTER_OP_THREADS
        args.graph_partition_mode = None
    print(f"Loading model: {args.model}")
    session = ORTSession(
        args.model,
        device_placement_file=args.device_placement_file,
        device_id=args.device_id,
        intra_op_threads=args.intra_op_threads,
        inter_op_threads=args.inter_op_threads,
        execution_mode=ORT_PARALLEL if args.execution_mode == "parallel" else 0,
        graph_partition_mode=args.graph_partition_mode,
        disable_cpu_mem_arena=args.disable_cpu_mem_arena,
        ort_library=args.ort_library,
    )
    print(
        f"Session created OK. ort={session.runtime.version} "
        f"inputs={len(session.input_names)}, outputs={len(session.output_names)}"
    )
    print(f"providers={session.provider_names}")
    print(f"device_placement_file={args.device_placement_file}")
    print(f"execution_mode={args.execution_mode}")
    print(f"global_intra_op_threads={args.intra_op_threads}")
    print(f"global_inter_op_threads={args.inter_op_threads}")
    print(f"graph_partition_mode={args.graph_partition_mode}")
    print(f"prepared_c_api={str(args.prepared_c_api).lower()}")
    print(f"disable_cpu_mem_arena={str(args.disable_cpu_mem_arena).lower()}")
    print(
        "session_memcpy_use_memory_pool_on="
        f"{session.memcpy_use_memory_pool_on}"
    )
    print("musa_plugin=false")
    print("musa_physical_streams_per_run=1")
    print(f"loaded_mudnn_libraries={loaded_mudnn_libraries()}")

    requests = load_requests(session, args.request_dir, args.limit)
    print(f"Loaded {len(requests)} requests")
    # 预热 provider/session 状态（在 warmup / 计量之外）
    run_one(session, requests[0])
    prepared_requests: Optional[list[PreparedRequest]] = None
    prepared_contexts: Optional[list[PreparedRunContext]] = None
    if args.prepared_c_api:
        prepare_start = time.perf_counter()
        prepared_requests = [
            session.prepare_request(
                request,
                output_key=prepared_output_key(request),
            )
            for request in requests
        ]
        prepared_contexts = [
            session.create_prepared_run_context()
            for _ in range(args.workers)
        ]
        print(
            f"Prepared {len(prepared_requests)} requests in "
            f"{time.perf_counter() - prepare_start:.3f}s"
        )

    request_count = max(1, int(round(args.qps * args.duration)))
    work_queue: "queue.Queue[Query]" = queue.Queue()
    producer_done = threading.Event()
    stop_event = threading.Event()
    warmup_start = threading.Event()
    start_event = threading.Event()
    warmup_start_time = [0.0]
    start_time = [0.0]
    warmup_barrier = threading.Barrier(args.workers + 1)
    ready_barrier = threading.Barrier(args.workers + 1)
    errors: list[BaseException] = []
    error_lock = threading.Lock()
    max_backlog = [0]
    backlog_lock = threading.Lock()
    results = [WorkerResult() for _ in range(args.workers)]

    workers = [
        threading.Thread(
            target=worker_loop,
            name=f"pressure-worker-{worker_id}",
            args=(
                worker_id,
                args.workers,
                session,
                requests,
                prepared_requests,
                (
                    prepared_contexts[worker_id]
                    if prepared_contexts is not None
                    else None
                ),
                work_queue,
                producer_done,
                stop_event,
                warmup_barrier,
                warmup_start,
                warmup_start_time,
                args.warmup_seconds,
                ready_barrier,
                start_event,
                results[worker_id],
                errors,
                error_lock,
                args.progress,
            ),
        )
        for worker_id in range(args.workers)
    ]
    producer = threading.Thread(
        target=producer_loop,
        name="pressure-producer",
        args=(
            args.mode,
            args.qps,
            args.workers,
            request_count,
            len(requests),
            start_event,
            start_time,
            work_queue,
            producer_done,
            stop_event,
            max_backlog,
            backlog_lock,
            errors,
            error_lock,
        ),
    )

    for worker in workers:
        worker.start()
    warmup_barrier.wait()
    warmup_start_time[0] = time.perf_counter()
    warmup_start.set()
    ready_barrier.wait()
    # Warmup has completed on every worker. Capture only the formal window;
    # the boundary backend records the existing D2H synchronize and never
    # inserts a synchronize of its own.
    os.environ["ORT_MUSA_PROFILE_TIMING_CAPTURE"] = "1"
    producer.start()
    cpu_time_start = os.times()
    start_time[0] = time.perf_counter()
    start_event.set()

    producer.join()
    for worker in workers:
        worker.join()
    end_time = time.perf_counter()
    cpu_time_end = os.times()
    args.cpu_process_seconds = (cpu_time_end.user + cpu_time_end.system -
                                cpu_time_start.user - cpu_time_start.system)

    os.environ["ORT_MUSA_PROFILE_TIMING_CAPTURE"] = "0"
    records = [record for result in results for record in result.records]
    session.flush_profiling_timing()
    musa_timing = parse_musa_completion_timing(
        args.output_dir, timing_csv, len(records)
    )
    write_results(
        args.output_dir, args, request_count, len(requests), records,
        start_time[0], end_time, max_backlog[0], errors, musa_timing,
        session.memcpy_use_memory_pool_on,
    )
    if prepared_contexts is not None:
        for context in prepared_contexts:
            context.close()
    if prepared_requests is not None:
        for request in prepared_requests:
            request.close()
    session.close()
    if errors:
        raise RuntimeError("Benchmark worker failed") from errors[0]
    if len(records) != request_count:
        raise RuntimeError(
            f"Benchmark incomplete: completed {len(records)} of {request_count} requests"
        )
    return 0


def main() -> int:
    args = parse_args()
    validate_args(args)
    return run(args)


if __name__ == "__main__":
    raise SystemExit(main())
