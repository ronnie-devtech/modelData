#!/usr/bin/env python3
"""ORT 1.18 C API session wrapper for the in-tree MUSA EP.

The wrapper intentionally mirrors the CUDA reference runner:
- ORT API v18 is called through the C API table.
- Input OrtValue construction and output release are outside the Run timer.
- MUSA is selected through the native SessionOptionsAppendExecutionProvider API.
- The device placement file is passed explicitly to MUSA.
"""

from __future__ import annotations

import argparse
import ctypes
import os
import time
from pathlib import Path
from typing import Any, Iterable, Optional

import numpy as np

ORT_API_VERSION = 18
ORT_DISABLE_ALL = 0
ORT_SEQUENTIAL = 0
ORT_PARALLEL = 1
ORT_LOGGING_LEVEL_WARNING = 2
ORT_MEM_TYPE_DEFAULT = 0
ORT_ALLOCATOR_TYPE_ARENA = 1
MEMCPY_POOL_ENV = "ORT_SESSION_MEMCPY_USE_MEMORY_POOL_ON"

VP = ctypes.c_void_p
STATUS = VP
PTR_SIZE = ctypes.sizeof(VP)


def get_memcpy_use_memory_pool_on() -> int:
    """Return the validated ORT host-boundary memory-pool setting."""
    value = os.environ.get(MEMCPY_POOL_ENV, "0")
    if value not in ("0", "1"):
        raise ValueError(
            f"{MEMCPY_POOL_ENV} must be exactly 0 or 1, got {value!r}"
        )
    return int(value)


# These offsets are generated from the ORT 1.18 public OrtApi definition.
# The runtime version is checked before the table is used.
API_INDEX = {
    "GetErrorCode": 1,
    "GetErrorMessage": 2,
    "CreateSession": 7,
    "Run": 9,
    "CreateSessionOptions": 10,
    "SetSessionExecutionMode": 13,
    "DisableMemPattern": 17,
    "DisableCpuMemArena": 19,
    "SetGraphOptimizationLevel": 23,
    "SetIntraOpNumThreads": 24,
    "SetInterOpNumThreads": 25,
    "SetOptimizedModelFilePath": 11,
    "EnableProfiling": 14,
    "CreateRunOptions": 39,
    "CreateTensorWithDataAsOrtValue": 49,
    "GetTensorMutableData": 51,
    "GetTensorElementType": 60,
    "GetDimensionsCount": 61,
    "GetDimensions": 62,
    "GetTensorTypeAndShape": 65,
    "CreateCpuMemoryInfo": 69,
    "AllocatorFree": 76,
    "GetAllocatorWithDefaultOptions": 78,
    "ReleaseEnv": 92,
    "ReleaseStatus": 93,
    "ReleaseMemoryInfo": 94,
    "ReleaseSession": 95,
    "ReleaseValue": 96,
    "ReleaseTensorTypeAndShapeInfo": 99,
    "ReleaseSessionOptions": 100,
    "CreateEnvWithGlobalThreadPools": 119,
    "DisablePerSessionThreads": 120,
    "CreateThreadingOptions": 121,
    "ReleaseThreadingOptions": 122,
    "AddSessionConfigEntry": 130,
    "SetGlobalIntraOpNumThreads": 147,
    "SetGlobalInterOpNumThreads": 148,
    "SessionOptionsAppendExecutionProvider": 216,
    "SessionGetInputCount": 30,
    "SessionGetOutputCount": 31,
    "SessionGetInputName": 36,
    "SessionGetOutputName": 37,
}


class _OrtApiBase(ctypes.Structure):
    _fields_ = [
        ("GetApi", ctypes.CFUNCTYPE(VP, ctypes.c_uint32)),
        ("GetVersionString", ctypes.CFUNCTYPE(ctypes.c_char_p)),
    ]


def _as_path(value: Optional[str | Path]) -> Optional[Path]:
    return None if value is None else Path(value).expanduser().resolve()


def _check_status(runtime: "OrtRuntime", status: VP) -> None:
    if status:
        message = runtime.call(
            "GetErrorMessage", ctypes.c_char_p, [VP], status
        )
        text = message.decode(errors="replace") if message else "unknown ORT error"
        code = runtime.call("GetErrorCode", ctypes.c_int, [VP], status)
        runtime.call("ReleaseStatus", None, [VP], status)
        raise RuntimeError(f"ORT error {code}: {text}")


class OrtRuntime:
    """Small ctypes projection of the ORT API needed by this benchmark."""

    def __init__(
        self,
        ort_library: Optional[str | Path] = None,
        musa_plugin_library: Optional[str | Path] = None,
    ) -> None:
        self._libraries: list[ctypes.CDLL] = []
        self._functions: dict[tuple[str, Any, tuple[Any, ...]], Any] = {}

        ort_path = self._resolve_ort_library(ort_library)
        self._load_global(ort_path)
        self._ort_so = self._libraries[-1]
        self._base = self._ort_so.OrtGetApiBase
        self._base.restype = ctypes.POINTER(_OrtApiBase)
        self._base.argtypes = []
        base = self._base()
        if not base:
            raise RuntimeError("OrtGetApiBase returned null")
        version_fn = base.contents.GetVersionString
        version_fn.restype = ctypes.c_char_p
        version = version_fn().decode(errors="replace")
        if not version.startswith("1.18."):
            raise RuntimeError(
                "MUSA C API runner requires ORT 1.18.x, "
                f"loaded runtime reports {version!r}"
            )
        get_api = base.contents.GetApi
        get_api.restype = VP
        get_api.argtypes = [ctypes.c_uint32]
        api = get_api(ORT_API_VERSION)
        if not api:
            raise RuntimeError(f"GetApi({ORT_API_VERSION}) returned null")
        self.version = version
        self._api_address = ctypes.cast(api, VP).value

    @staticmethod
    def _resolve_ort_library(value: Optional[str | Path]) -> Path:
        if value:
            path = Path(value).expanduser().resolve()
        else:
            env_path = os.environ.get("ORT_MUSA_ORT_LIB")
            if not env_path:
                raise RuntimeError(
                    "Set ORT_MUSA_ORT_LIB or pass --ort-library to use the native JD-ORT 1.18 libonnxruntime"
                )
            path = Path(env_path).expanduser().resolve()
        if not path.is_file():
            raise FileNotFoundError(f"ORT library does not exist: {path}")
        return path

    def _load_global(self, path: Path) -> None:
        self._libraries.append(ctypes.CDLL(str(path), mode=ctypes.RTLD_GLOBAL))

    def function(
        self,
        name: str,
        restype: Any,
        argtypes: Iterable[Any],
    ) -> Any:
        args = tuple(argtypes)
        key = (name, restype, args)
        if key not in self._functions:
            index = API_INDEX[name]
            slot = self._api_address + index * PTR_SIZE
            address = VP.from_address(slot).value
            if not address:
                raise RuntimeError(
                    f"ORT API function {name} at index {index} is null"
                )
            fn_type = ctypes.CFUNCTYPE(restype, *args)
            self._functions[key] = fn_type(address)
        return self._functions[key]

    def call(self, name: str, restype: Any, argtypes: Iterable[Any], *args: Any) -> Any:
        return self.function(name, restype, argtypes)(*args)

    def check(self, status: VP) -> None:
        _check_status(self, status)


class PreparedRequest:
    """Immutable CPU input OrtValues reused across Run calls."""

    def __init__(
        self,
        session: "CApiSession",
        arrays: list[np.ndarray],
        values: list[VP],
        output_key: Any,
    ) -> None:
        self._session = session
        self._arrays = arrays
        self._values = values
        self.input_array = (VP * len(values))(*values)
        self.output_key = output_key
        self._closed = False

    @property
    def input_count(self) -> int:
        return len(self._values)

    def close(self) -> None:
        if self._closed:
            return
        self._closed = True
        for value in self._values:
            self._session.runtime.call("ReleaseValue", None, [VP], value)
        self._values.clear()
        self._arrays.clear()


class PreparedRunContext:
    """Per-worker reusable output OrtValues, grouped by dynamic output shape."""

    def __init__(self, session: "CApiSession") -> None:
        self._session = session
        self._outputs: dict[Any, Any] = {}
        self._closed = False

    def output_array(self, output_key: Any) -> Any:
        if self._closed:
            raise RuntimeError("Prepared run context is closed")
        output_array = self._outputs.get(output_key)
        if output_array is None:
            output_array = (VP * len(self._session.output_names))()
            self._outputs[output_key] = output_array
        return output_array

    def outputs(self, output_key: Any) -> list[VP]:
        output_array = self.output_array(output_key)
        return [output_array[i] for i in range(len(output_array))]

    def close(self) -> None:
        if self._closed:
            return
        self._closed = True
        for output_array in self._outputs.values():
            for value in output_array:
                if value:
                    self._session.runtime.call("ReleaseValue", None, [VP], value)
        self._outputs.clear()


class CApiSession:
    """One ORT Session, safe to invoke concurrently from host threads."""

    def __init__(
        self,
        model_path: str | Path,
        *,
        device_placement_file: str | Path,
        device_id: int = 0,
        intra_op_threads: int = 4,
        inter_op_threads: int = 1,
        execution_mode: int = ORT_SEQUENTIAL,
        graph_partition_mode: Optional[int] = None,
        graph_partition_gpu_stream_count: int = 1,
        disable_mem_pattern: bool = False,
        disable_cpu_mem_arena: bool = False,
        ort_library: Optional[str | Path] = None,
        musa_plugin_library: Optional[str | Path] = None,
    ) -> None:
        self.model_path = Path(model_path).expanduser().resolve()
        self._onnx_path = self.model_path
        self.device_placement_file = (
            Path(device_placement_file).expanduser().resolve()
        )
        if not self.model_path.is_file():
            raise FileNotFoundError(f"Model does not exist: {self.model_path}")
        if not self.device_placement_file.is_file():
            raise FileNotFoundError(
                "Device placement file does not exist: "
                f"{self.device_placement_file}"
            )
        if device_id < 0:
            raise ValueError(f"device_id must be non-negative: {device_id}")

        self.memcpy_use_memory_pool_on = get_memcpy_use_memory_pool_on()
        self.runtime = OrtRuntime(ort_library, musa_plugin_library)
        self.device_id = device_id
        self.intra_op_threads = intra_op_threads
        self.inter_op_threads = inter_op_threads
        self.execution_mode = execution_mode
        self.graph_partition_mode = graph_partition_mode
        self.graph_partition_gpu_stream_count = graph_partition_gpu_stream_count
        self.disable_mem_pattern = disable_mem_pattern
        self.disable_cpu_mem_arena = disable_cpu_mem_arena
        self.env = VP()
        self.threading_options = VP()
        self.session_options = VP()
        self.session = VP()
        self.memory_info = VP()
        self.input_names: list[str] = []
        self.output_names: list[str] = []
        self.provider_names: list[str] = []
        self._closed = False

        try:
            self._create_environment()
            self._create_session_options()
            self._register_and_append_eps()
            optimized_model_path = os.environ.get("ORT_NATIVE_OPTIMIZED_MODEL_PATH")
            profile_prefix = os.environ.get("ORT_NATIVE_PROFILE_PREFIX")
            if profile_prefix:
                self._status(
                    "EnableProfiling",
                    self.session_options,
                    os.fsencode(profile_prefix),
                )
            if optimized_model_path:
                self._status(
                    "SetOptimizedModelFilePath",
                    self.session_options,
                    os.fsencode(optimized_model_path),
                )
            # The rank-N CPU shim uses the placement file while ORT asks each
            # EP for graph capability.  MUSA receives the path as a provider
            # option, while the shim is intentionally independent of MUSA
            # options.  Bridge the explicit runner argument only for session
            # creation, then restore the caller's process environment.
            placement_env_key = "MUSA_EP_DEVICE_PLACEMENT_FILE"
            previous_placement = os.environ.get(placement_env_key)
            os.environ[placement_env_key] = str(self.device_placement_file)
            try:
                self._create_session()
            finally:
                if previous_placement is None:
                    os.environ.pop(placement_env_key, None)
                else:
                    os.environ[placement_env_key] = previous_placement
            self.input_names = self._get_names(
                "SessionGetInputCount", "SessionGetInputName"
            )
            self.output_names = self._get_names(
                "SessionGetOutputCount", "SessionGetOutputName"
            )
            self._create_memory_info()
            self._prepared_input_names = (
                ctypes.c_char_p * len(self.input_names)
            )(*[name.encode() for name in self.input_names])
            self._prepared_output_names = (
                ctypes.c_char_p * len(self.output_names)
            )(*[name.encode() for name in self.output_names])
            self._prepared_run_fn = self.runtime.function(
                "Run", VP, self._signature("Run")
            )
        except BaseException:
            self.close()
            raise

    def _status(self, name: str, *args: Any) -> None:
        self.runtime.check(
            self.runtime.call(name, VP, self._signature(name), *args)
        )

    @staticmethod
    def _signature(name: str) -> list[Any]:
        signatures = {
            "CreateThreadingOptions": [ctypes.POINTER(VP)],
            "SetGlobalIntraOpNumThreads": [VP, ctypes.c_int],
            "SetGlobalInterOpNumThreads": [VP, ctypes.c_int],
            "CreateEnvWithGlobalThreadPools": [
                ctypes.c_int,
                ctypes.c_char_p,
                VP,
                ctypes.POINTER(VP),
            ],
            "CreateSessionOptions": [ctypes.POINTER(VP)],
            "SetGraphOptimizationLevel": [VP, ctypes.c_int],
            "SetOptimizedModelFilePath": [VP, ctypes.c_char_p],
            "EnableProfiling": [VP, ctypes.c_char_p],
            "SetIntraOpNumThreads": [VP, ctypes.c_int],
            "SetInterOpNumThreads": [VP, ctypes.c_int],
            "SetSessionExecutionMode": [VP, ctypes.c_int],
            "DisableMemPattern": [VP],
            "DisablePerSessionThreads": [VP],
            "DisableCpuMemArena": [VP],
            "AddSessionConfigEntry": [VP, ctypes.c_char_p, ctypes.c_char_p],
            "SessionOptionsAppendExecutionProvider": [
                VP,
                ctypes.c_char_p,
                ctypes.POINTER(ctypes.c_char_p),
                ctypes.POINTER(ctypes.c_char_p),
                ctypes.c_size_t,
            ],
            "CreateSession": [VP, ctypes.c_char_p, VP, ctypes.POINTER(VP)],
            "SessionGetInputCount": [VP, ctypes.POINTER(ctypes.c_size_t)],
            "SessionGetOutputCount": [VP, ctypes.POINTER(ctypes.c_size_t)],
            "SessionGetInputName": [
                VP,
                ctypes.c_size_t,
                VP,
                ctypes.POINTER(ctypes.c_char_p),
            ],
            "SessionGetOutputName": [
                VP,
                ctypes.c_size_t,
                VP,
                ctypes.POINTER(ctypes.c_char_p),
            ],
            "GetAllocatorWithDefaultOptions": [ctypes.POINTER(VP)],
            "AllocatorFree": [VP, ctypes.c_void_p],
            "CreateCpuMemoryInfo": [
                ctypes.c_int,
                ctypes.c_int,
                ctypes.POINTER(VP),
            ],
            "CreateTensorWithDataAsOrtValue": [
                VP,
                ctypes.c_void_p,
                ctypes.c_size_t,
                ctypes.POINTER(ctypes.c_int64),
                ctypes.c_size_t,
                ctypes.c_int,
                ctypes.POINTER(VP),
            ],
            "Run": [
                VP,
                VP,
                ctypes.POINTER(ctypes.c_char_p),
                ctypes.POINTER(VP),
                ctypes.c_size_t,
                ctypes.POINTER(ctypes.c_char_p),
                ctypes.c_size_t,
                ctypes.POINTER(VP),
            ],
            "ReleaseValue": [VP],
        }
        try:
            return signatures[name]
        except KeyError as exc:
            raise KeyError(f"Missing C API signature for {name}") from exc

    def _create_environment(self) -> None:
        self._status("CreateThreadingOptions", ctypes.byref(self.threading_options))
        try:
            self._status(
                "SetGlobalIntraOpNumThreads",
                self.threading_options,
                self.intra_op_threads,
            )
            self._status(
                "SetGlobalInterOpNumThreads",
                self.threading_options,
                self.inter_op_threads,
            )
            self._status(
                "CreateEnvWithGlobalThreadPools",
                ORT_LOGGING_LEVEL_WARNING,
                b"musa_recommendation_pressure",
                self.threading_options,
                ctypes.byref(self.env),
            )
        finally:
            if self.threading_options:
                self.runtime.call(
                    "ReleaseThreadingOptions",
                    None,
                    [VP],
                    self.threading_options,
                )
                self.threading_options = VP()

    def _create_session_options(self) -> None:
        self._status(
            "CreateSessionOptions", ctypes.byref(self.session_options)
        )
        self._status(
            "SetGraphOptimizationLevel",
            self.session_options,
            ORT_DISABLE_ALL,
        )
        self._status(
            "SetIntraOpNumThreads", self.session_options, self.intra_op_threads
        )
        self._status(
            "SetInterOpNumThreads", self.session_options, self.inter_op_threads
        )
        self._status(
            "SetSessionExecutionMode", self.session_options, self.execution_mode
        )
        if self.disable_mem_pattern:
            self._status("DisableMemPattern", self.session_options)
        if self.disable_cpu_mem_arena:
            self._status("DisableCpuMemArena", self.session_options)
        self._status(
            "DisablePerSessionThreads", self.session_options
        )
        gpu_allocator_mode = os.environ.get(
            "ORT_MUSA_NATIVE_GPU_INDEPENDENT_STREAM_ALLOCATOR", "false"
        )
        for key, value in (
            ("session.intra_op.allow_spinning", "0"),
            ("session.inter_op.allow_spinning", "0"),
            (
                "session.gpu_use_independent_stream_allocator",
                gpu_allocator_mode,
            ),
            (
                "session.memcpy_use_memory_pool_on",
                str(self.memcpy_use_memory_pool_on),
            ),
        ):
            self._status(
                "AddSessionConfigEntry",
                self.session_options,
                key.encode(),
                value.encode(),
            )
        if self.graph_partition_mode is not None:
            if self.execution_mode != ORT_PARALLEL:
                raise ValueError(
                    "graph_partition_mode requires ORT_PARALLEL execution"
                )
            for key, value in (
                ("session.graph_partition_mode", str(self.graph_partition_mode)),
                ("session.gpu_parallel_run_mode", "0"),
                (
                    "session.graph_partition_gpu_stream_count",
                    str(self.graph_partition_gpu_stream_count),
                ),
                ("session.subgraph_reallocation_batch_memcpy_h2d_on", "1"),
                ("session.subgraph_reallocation_batch_memcpy_d2h_on", "1"),
            ):
                self._status(
                    "AddSessionConfigEntry",
                    self.session_options,
                    key.encode(),
                    value.encode(),
                )

    def _register_and_append_eps(self) -> None:
        keys = (ctypes.c_char_p * 2)(
            b"device_id", b"device_placement_file"
        )
        values = (ctypes.c_char_p * 2)(
            str(self.device_id).encode(), os.fsencode(str(self.device_placement_file))
        )
        self._status(
            "SessionOptionsAppendExecutionProvider",
            self.session_options,
            b"MUSAExecutionProvider",
            keys,
            values,
            2,
        )
        self.provider_names = ["MUSAExecutionProvider", "CPUExecutionProvider"]

    def _create_session(self) -> None:
        self._status(
            "CreateSession",
            self.env,
            os.fsencode(str(self.model_path)),
            self.session_options,
            ctypes.byref(self.session),
        )

    def _get_names(self, count_name: str, name_name: str) -> list[str]:
        count = ctypes.c_size_t()
        self._status(count_name, self.session, ctypes.byref(count))
        allocator = VP()
        self._status(
            "GetAllocatorWithDefaultOptions", ctypes.byref(allocator)
        )
        names: list[str] = []
        for index in range(count.value):
            raw = ctypes.c_char_p()
            self._status(
                name_name,
                self.session,
                index,
                allocator,
                ctypes.byref(raw),
            )
            names.append(raw.value.decode(errors="replace"))
            self._status("AllocatorFree", allocator, raw)
        return names

    def _create_memory_info(self) -> None:
        self._status(
            "CreateCpuMemoryInfo",
            0,
            ORT_MEM_TYPE_DEFAULT,
            ctypes.byref(self.memory_info),
        )

    def run(
        self,
        feed_dict: dict[str, np.ndarray],
        *,
        include_timestamps: bool = False,
    ) -> (
        tuple[list[VP], float]
        | tuple[list[VP], float, int, int]
    ):
        if self._closed:
            raise RuntimeError("Session is already closed")
        arrays: list[np.ndarray] = []
        input_values: list[VP] = []
        for name in self.input_names:
            if name not in feed_dict:
                raise KeyError(f"Missing model input: {name}")
            array = np.ascontiguousarray(feed_dict[name])
            arrays.append(array)
            shape = tuple(int(value) for value in array.shape)
            shape_array = (ctypes.c_int64 * len(shape))(*shape)
            value = VP()
            self._status(
                "CreateTensorWithDataAsOrtValue",
                self.memory_info,
                array.ctypes.data_as(ctypes.c_void_p),
                array.nbytes,
                shape_array,
                len(shape),
                _numpy_to_onnx_type(array),
                ctypes.byref(value),
            )
            input_values.append(value)

        input_names = (ctypes.c_char_p * len(self.input_names))(
            *[name.encode() for name in self.input_names]
        )
        input_array = (VP * len(input_values))(*input_values)
        output_names = (ctypes.c_char_p * len(self.output_names))(
            *[name.encode() for name in self.output_names]
        )
        output_array = (VP * len(self.output_names))()

        run_fn = self.runtime.function(
            "Run",
            VP,
            self._signature("Run"),
        )
        start = time.perf_counter()
        elapsed: Optional[float] = None
        try:
            status = run_fn(
                self.session,
                VP(),
                input_names,
                input_array,
                len(input_values),
                output_names,
                len(self.output_names),
                output_array,
            )
            self.runtime.check(status)
            end = time.perf_counter()
            elapsed = end - start
        finally:
            for value in input_values:
                self.runtime.call("ReleaseValue", None, [VP], value)
        if elapsed is None:
            raise RuntimeError("ORT Run did not return a timing result")
        outputs = [output_array[i] for i in range(len(self.output_names))]
        if include_timestamps:
            return outputs, elapsed, int(start * 1.0e9), int(end * 1.0e9)
        return outputs, elapsed

    def prepare_request(
        self,
        feed_dict: dict[str, np.ndarray],
        *,
        output_key: Any,
    ) -> PreparedRequest:
        """Create input OrtValues once for a read-only benchmark request."""
        if self._closed:
            raise RuntimeError("Session is already closed")
        arrays: list[np.ndarray] = []
        values: list[VP] = []
        try:
            for name in self.input_names:
                if name not in feed_dict:
                    raise KeyError(f"Missing model input: {name}")
                array = np.ascontiguousarray(feed_dict[name])
                arrays.append(array)
                shape = tuple(int(value) for value in array.shape)
                shape_array = (ctypes.c_int64 * len(shape))(*shape)
                value = VP()
                self._status(
                    "CreateTensorWithDataAsOrtValue",
                    self.memory_info,
                    array.ctypes.data_as(ctypes.c_void_p),
                    array.nbytes,
                    shape_array,
                    len(shape),
                    _numpy_to_onnx_type(array),
                    ctypes.byref(value),
                )
                values.append(value)
        except BaseException:
            for value in values:
                self.runtime.call("ReleaseValue", None, [VP], value)
            raise
        return PreparedRequest(self, arrays, values, output_key)

    def create_prepared_run_context(self) -> PreparedRunContext:
        if self._closed:
            raise RuntimeError("Session is already closed")
        return PreparedRunContext(self)

    def run_prepared(
        self,
        request: PreparedRequest,
        context: PreparedRunContext,
        *,
        include_timestamps: bool = False,
    ) -> float | tuple[float, int, int]:
        """Run with pre-created inputs and per-worker reusable outputs."""
        if self._closed:
            raise RuntimeError("Session is already closed")
        if request._closed:
            raise RuntimeError("Prepared request is closed")
        if request._session is not self or context._session is not self:
            raise ValueError("Prepared request/context belongs to another session")

        output_array = context.output_array(request.output_key)
        start = time.perf_counter()
        status = self._prepared_run_fn(
            self.session,
            VP(),
            self._prepared_input_names,
            request.input_array,
            request.input_count,
            self._prepared_output_names,
            len(self.output_names),
            output_array,
        )
        self.runtime.check(status)
        end = time.perf_counter()
        elapsed = end - start
        if include_timestamps:
            return elapsed, int(start * 1.0e9), int(end * 1.0e9)
        return elapsed

    def release_outputs(self, outputs: Iterable[VP]) -> None:
        for value in outputs:
            if value:
                self.runtime.call("ReleaseValue", None, [VP], value)

    def flush_profiling_timing(self) -> None:
        """Flush captured MUSA timing samples without synchronizing a stream."""
        if self._closed:
            raise RuntimeError("Session is already closed")
        runtime = self.runtime._ort_so
        try:
            flush = runtime.OrtMusaFlushProfilingTiming
        except AttributeError as exc:
            raise RuntimeError("In-tree ORT does not export timing flush") from exc
        flush.argtypes = []
        flush.restype = None
        flush()

    def close(self) -> None:
        if self._closed:
            return
        self._closed = True
        if self.session:
            self.runtime.call("ReleaseSession", None, [VP], self.session)
            self.session = VP()
        if self.memory_info:
            self.runtime.call("ReleaseMemoryInfo", None, [VP], self.memory_info)
            self.memory_info = VP()
        if self.session_options:
            self.runtime.call(
                "ReleaseSessionOptions", None, [VP], self.session_options
            )
            self.session_options = VP()
        if self.env:
            self.runtime.call("ReleaseEnv", None, [VP], self.env)
            self.env = VP()

    def __enter__(self) -> "CApiSession":
        return self

    def __exit__(self, exc_type: Any, exc: Any, tb: Any) -> None:
        self.close()


ONNX_TO_NP_DTYPE = {
    1: np.float32,
    11: np.float64,
    5: np.int16,
    6: np.int32,
    7: np.int64,
}
NP_DTYPE_TO_ONNX = {
    np.dtype(np.float32): 1,
    np.dtype(np.float64): 11,
    np.dtype(np.float16): 10,
    np.dtype(np.int16): 5,
    np.dtype(np.int32): 6,
    np.dtype(np.int64): 7,
    np.dtype(np.uint8): 2,
    np.dtype(np.int8): 3,
    np.dtype(np.bool_): 9,
}


def _numpy_to_onnx_type(array: np.ndarray) -> int:
    dtype = np.dtype(array.dtype)
    try:
        return NP_DTYPE_TO_ONNX[dtype]
    except KeyError as exc:
        raise TypeError(f"Unsupported NumPy dtype for ORT input: {dtype}") from exc


def get_model_input_dtypes(onnx_path: str | Path) -> dict[str, int]:
    import onnx

    model = onnx.load(str(onnx_path), load_external_data=False)
    return {
        value.name: value.type.tensor_type.elem_type
        for value in model.graph.input
    }


def load_request(
    session: CApiSession,
    request_path: str | Path,
    dtype_map: dict[str, int] | None = None,
) -> dict[str, np.ndarray]:
    if dtype_map is None:
        dtype_map = get_model_input_dtypes(session.model_path)
    with np.load(request_path, allow_pickle=False) as archive:
        request: dict[str, np.ndarray] = {}
        missing: list[str] = []
        for name in session.input_names:
            if name not in archive:
                missing.append(name)
                continue
            array = archive[name]
            expected = ONNX_TO_NP_DTYPE.get(dtype_map.get(name, 0))
            if expected is not None and array.dtype != expected:
                array = array.astype(expected)
            request[name] = array
    if missing:
        raise FileNotFoundError(
            f"{request_path} is missing {len(missing)} model inputs; "
            f"first missing={missing[:5]}"
        )
    return request


def ort_value_to_numpy(session: CApiSession, value: VP) -> np.ndarray:
    """Copy one output OrtValue to a NumPy array for smoke/debug only."""
    get_tts = session.runtime.function(
        "GetTensorTypeAndShape",
        VP,
        [VP, ctypes.POINTER(VP)],
    )
    get_type = session.runtime.function(
        "GetTensorElementType",
        VP,
        [VP, ctypes.POINTER(ctypes.c_int32)],
    )
    get_dims_count = session.runtime.function(
        "GetDimensionsCount",
        VP,
        [VP, ctypes.POINTER(ctypes.c_size_t)],
    )
    get_dims = session.runtime.function(
        "GetDimensions",
        VP,
        [VP, ctypes.POINTER(ctypes.c_int64), ctypes.c_size_t],
    )
    get_data = session.runtime.function(
        "GetTensorMutableData",
        VP,
        [VP, ctypes.POINTER(ctypes.c_void_p)],
    )
    release_tts = session.runtime.function(
        "ReleaseTensorTypeAndShapeInfo",
        None,
        [VP],
    )

    tts = VP()
    session.runtime.check(get_tts(value, ctypes.byref(tts)))
    element_type = ctypes.c_int32()
    session.runtime.check(get_type(tts, ctypes.byref(element_type)))
    ndim = ctypes.c_size_t()
    session.runtime.check(get_dims_count(tts, ctypes.byref(ndim)))
    dimensions = (ctypes.c_int64 * ndim.value)()
    session.runtime.check(get_dims(tts, dimensions, ndim.value))
    raw = ctypes.c_void_p()
    session.runtime.check(get_data(value, ctypes.byref(raw)))
    release_tts(tts)

    dtype = {
        1: np.float32,
        11: np.float64,
        6: np.int32,
        7: np.int64,
        10: np.float16,
    }.get(element_type.value, np.float32)
    shape = tuple(int(dimensions[i]) for i in range(ndim.value))
    count = int(np.prod(shape, dtype=np.int64)) if shape else 1
    if count == 0:
        return np.empty(shape, dtype=dtype)
    buffer = (ctypes.c_byte * (count * np.dtype(dtype).itemsize)).from_address(
        raw.value
    )
    return np.frombuffer(buffer, dtype=dtype).reshape(shape).copy()


def _sorted_npz_files(request_dir: Path) -> list[Path]:
    def key(path: Path) -> tuple[int, object, str]:
        prefix = path.name.split("_", 1)[0]
        if prefix.isdigit():
            return (0, int(prefix), path.name)
        return (1, path.name, path.name)

    return sorted(request_dir.glob("*.npz"), key=key)


def main() -> int:
    parser = argparse.ArgumentParser(
        description="Run one recommendation-model request through MUSA ORT C API."
    )
    parser.add_argument("--model", type=Path, required=True)
    parser.add_argument("--request", type=Path, required=True)
    parser.add_argument("--device-placement-file", type=Path, required=True)
    parser.add_argument("--ort-library", type=Path, default=None)
    parser.add_argument("--device-id", type=int, default=0)
    parser.add_argument("--repeat", type=int, default=1)
    args = parser.parse_args()
    if args.repeat <= 0:
        parser.error("--repeat must be positive")

    with CApiSession(
        args.model,
        device_placement_file=args.device_placement_file,
        device_id=args.device_id,
        ort_library=args.ort_library,
    ) as session:
        request = load_request(session, args.request)
        print(f"ort_version={session.runtime.version}")
        print(f"model={session.model_path}")
        print(f"device_placement_file={session.device_placement_file}")
        print(f"ort_library={args.ort_library if args.ort_library is not None else os.environ.get('ORT_MUSA_ORT_LIB')}")
        print(f"inputs={len(session.input_names)}")
        print(f"outputs={len(session.output_names)}")
        print(f"providers={session.provider_names}")
        for index in range(args.repeat):
            outputs, elapsed = session.run(request)
            print(f"run_{index}_time_ms={elapsed * 1000.0:.3f}")
            if index == args.repeat - 1:
                for output_name, output in zip(session.output_names, outputs):
                    array = ort_value_to_numpy(session, output)
                    print(
                        f"output={output_name} shape={list(array.shape)} "
                        f"dtype={array.dtype} min={array.min():.6g} "
                        f"max={array.max():.6g} mean={array.mean():.6g}"
                    )
            session.release_outputs(outputs)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
