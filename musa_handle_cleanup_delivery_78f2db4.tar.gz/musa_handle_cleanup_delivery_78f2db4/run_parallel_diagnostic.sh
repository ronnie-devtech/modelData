#!/usr/bin/env bash
set -euo pipefail

die() { echo "[MUSA_PARALLEL_DIAG] ERROR: $*" >&2; exit 2; }
HERE=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
ONNXRUNTIME_ROOT=${ONNXRUNTIME_ROOT:-}
MODEL_DATA_ROOT=${MODEL_DATA_ROOT:-}
RESULT_ROOT=${RESULT_ROOT:-}
[[ -n "$ONNXRUNTIME_ROOT" ]] || die 'set ONNXRUNTIME_ROOT to the JD-MUSA checkout'
[[ -n "$MODEL_DATA_ROOT" ]] || die 'set MODEL_DATA_ROOT to the original_JDdata directory'
[[ -n "$RESULT_ROOT" ]] || die 'set RESULT_ROOT to a writable result directory'

for file in "$MODEL_DATA_ROOT/optimized_model.onnx" "$MODEL_DATA_ROOT/device.txt" "$MODEL_DATA_ROOT/req_799_npz"; do
  [[ -e "$file" ]] || die "missing $file"
done

export MUSA_HOME=${MUSA_HOME:-/usr/local/musa}
export LD_LIBRARY_PATH="$ONNXRUNTIME_ROOT/thirdparty/METIS_LIB/lib:$ONNXRUNTIME_ROOT/thirdparty/gfortran:${LD_LIBRARY_PATH:-}"
export MUSA_VISIBLE_DEVICES=${MUSA_VISIBLE_DEVICES:-0}
export ORT_MUSA_ENABLE_TF32=${ORT_MUSA_ENABLE_TF32:-1}
export ORT_MUSA_ALLOCATOR_CACHE_LIMIT_MB=${ORT_MUSA_ALLOCATOR_CACHE_LIMIT_MB:-4096}
export ORT_SESSION_MEMCPY_USE_MEMORY_POOL_ON=${ORT_SESSION_MEMCPY_USE_MEMORY_POOL_ON:-0}
export MUSA_DIAG_STRACE=${MUSA_DIAG_STRACE:-1}
export MUSA_DIAG_LD_DEBUG=${MUSA_DIAG_LD_DEBUG:-1}
export MUSA_DIAG_TRACE_ALL=${MUSA_DIAG_TRACE_ALL:-0}

ort_lib=${ORT_MUSA_ORT_LIB:-$HERE/libonnxruntime.so.1.18.0}
trace_lib=${MUSA_FREE_TRACE_LIB:-$HERE/libmusa_free_trace.so}
pressure=${PRESSURE_NATIVE_CAPI:-$HERE/pressure_native_capi.py}
[[ -f "$ort_lib" ]] || die "missing ORT library: $ort_lib"
[[ -f "$trace_lib" ]] || die "missing trace library: $trace_lib"
[[ -f "$pressure" ]] || die "missing pressure script: $pressure"

run_result="$RESULT_ROOT/parallel"
if [[ -d "$run_result" ]] && find "$run_result" -mindepth 1 -print -quit 2>/dev/null | grep -q .; then
  run_result="$RESULT_ROOT/parallel_diagnostic_$(date +%Y%m%d_%H%M%S)"
fi

exec "$HERE/collect_musa_diagnostics.sh" \
  --ort-lib "$ort_lib" --trace-lib "$trace_lib" \
  --result-dir "$run_result" --clean-timing -- \
  taskset -c "${MUSA_DIAG_CPU_LIST:-0-13}" \
  python3 -u "$pressure" \
    --model "$MODEL_DATA_ROOT/optimized_model.onnx" \
    --request-dir "$MODEL_DATA_ROOT/req_799_npz" \
    --device-placement-file "$MODEL_DATA_ROOT/device.txt" \
    --ort-library "$ort_lib" \
    --device-id 0 --mode uniform --qps 160 --workers 16 \
    --execution-mode parallel --parallel-inter-op 12 \
    --disable-cpu-mem-arena --warmup-seconds 20 --duration 60 \
    --output-dir "$run_result"
